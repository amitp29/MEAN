//Set up default mongoose connection
const connection_string = 'mongodb://amit:amit@localhost:27017/testdb';

// mongoose.connect('mongodb://user:pass@localhost:port/database', { autoIndex: false });

module.exports = connection_string;